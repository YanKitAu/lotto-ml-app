# main.py
import subprocess
import sys
import os

def main():
    if hasattr(sys, '_MEIPASS'):
        os.chdir(sys._MEIPASS)

    subprocess.run([
        sys.executable, '-m', 'streamlit', 'run', 'app.py',
        '--server.headless=true',
        '--server.enableCORS=false',
        '--server.enableXsrfProtection=false'
    ])

if __name__ == "__main__":
    main()