# 六合彩AI預測實驗

本專案為教育用途，展示「AI 無法預測隨機彩票」。

## 📦 內容
- `app.py`: Streamlit 網頁主程式
- `main.py`: PyInstaller 啟動器
- `build.bat`: 一鍵打包成 .exe
- `run.bat`: 一鍵運行（需安裝 Python）
- `data/`: 歷史開獎數據
- `icon.ico`: 應用圖示

## ▶️ 使用方式

### 開發模式（需 Python）
1. 安裝套件：`pip install streamlit pandas scikit-learn xgboost matplotlib seaborn requests`
2. 執行 `run.bat`

### 打包成 .exe
1. 執行 `build.bat`
2. 生成 `dist/六合彩AI預測實驗.exe`
3. 雙擊即可運行（自動開啟瀏覽器）

## ⚠️ 注意
- 打包後約 300MB，因包含完整 Python 環境
- 第一次運行較慢（解壓縮中）
- 本工具不鼓勵賭博，僅供教育研究