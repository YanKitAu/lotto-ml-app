@st.cache_data
def load_data():
    # 優先載入本地數據
    if os.path.exists("data/marksix_history.csv"):
        try:
            df = pd.read_csv("data/marksix_history.csv")
            st.info("✅ 已載入本地數據（data/marksix_history.csv）")
            return df
        except Exception as e:
            st.warning(f"⚠️ 無法讀取本地數據：{e}")

    # 否則下載
    url = "https://raw.githubusercontent.com/wongchunglam/hk_marksix_history/main/data/marksix_history.csv"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            df = pd.read_csv(StringIO(response.text))
            return df
        else:
            st.error("❌ 無法下載數據，請檢查網絡")
            return None
    except Exception as e:
        st.error(f"❌ 數據載入失敗：{e}")
        return None